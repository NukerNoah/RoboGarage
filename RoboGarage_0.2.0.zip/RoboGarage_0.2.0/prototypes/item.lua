data:extend({
	{
    type = "item",
    name = "robo-garage",
    icon = "__base__/graphics/icons/roboport.png",
    flags = {"goes-to-quickbar"},
    subgroup = "logistic-network",
    order = "c[signal]-b[roboport]",
    place_result = "robo-garage",
    stack_size = 5
	}
})