data:extend({
{
    type = "recipe",
    name = "robo-garage",
    enabled = false,
    ingredients =
    {
      {"steel-plate", 15},
      {"iron-gear-wheel", 15},
      {"electronic-circuit", 30}
    },
    result = "robo-garage",
    energy_required = 10
  }
 })